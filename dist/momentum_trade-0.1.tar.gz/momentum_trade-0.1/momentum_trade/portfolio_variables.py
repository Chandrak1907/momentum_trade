PORTFOLIO_VALUE = 100000
RISK_FACTOR = 0.001
# Enter the number of days of past data to build a linear regression model
PAST_DURATION = 90
## Enter the google spreadsheet key 
spreadsheet_key = '' 